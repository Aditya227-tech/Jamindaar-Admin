<?php
return array(
    'current_version' => '1.2.5',
    'update_version' => '1.2.6'
);
