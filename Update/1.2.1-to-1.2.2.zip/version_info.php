<?php
return array(
    'current_version' => '1.2.1',
    'update_version' => '1.2.2'
);
