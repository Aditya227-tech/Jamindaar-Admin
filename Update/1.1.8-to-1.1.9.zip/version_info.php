<?php
return array(
    'current_version'=>'1.1.8',
    'update_version'=>'1.1.9'
);
