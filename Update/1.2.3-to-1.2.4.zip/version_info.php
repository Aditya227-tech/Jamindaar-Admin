<?php
return array(
    'current_version' => '1.2.3',
    'update_version' => '1.2.4'
);
