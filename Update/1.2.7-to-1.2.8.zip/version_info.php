<?php
return array(
    'current_version' => '1.2.7',
    'update_version' => '1.2.8'
);
