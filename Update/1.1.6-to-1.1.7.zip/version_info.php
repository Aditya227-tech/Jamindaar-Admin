<?php
return array(
    'current_version'=>'1.1.6',
    'update_version'=>'1.1.7'
);
