<?php
return array(
    'current_version'=>'1.0.8',
    'update_version'=>'1.0.9'
);
