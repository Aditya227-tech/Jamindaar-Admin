<?php
return array(
    'current_version' => '1.2.2',
    'update_version' => '1.2.3'
);
