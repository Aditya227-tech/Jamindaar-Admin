<?php
return array(
    'current_version' => '1.2.9',
    'update_version' => '1.3.0'
);
